/* 
 * Autores: 
 * Juan Calixto García del Hoyo
 * Ricardo Boza Villar
 */
public final class TextStats {

    private final int vowels;
    private final int letters;
    private final int uppercase;
    private final int words;

    public TextStats(int vowels, int letters, int uppercase, int words) {
        this.vowels = vowels;
        this.letters = letters;
        this.uppercase = uppercase;
        this.words = words;
    }

    public static TextStats empty() {
        return new TextStats(0, 0, 0, 0);
    }

    public int getVowels() {
        return vowels;
    }

    public int getLetters() {
        return letters;
    }

    public int getUppercase() {
        return uppercase;
    }

    public int getWords() {
        return words;
    }
}
