import java.text.Normalizer;
/* 
 * Autores: 
 * Juan Calixto García del Hoyo
 * Ricardo Boza Villar
 */
public final class TextStatsCalculator {

    public TextStats calculate(String text) {
        if (text == null || text.isEmpty()) {
            return TextStats.empty();
        }

        int vowels = 0;
        int letters = 0;
        int uppercase = 0;
        int words = countWords(text);

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (Character.isLetter(c)) {
                letters++;

                if (Character.isUpperCase(c)) {
                    uppercase++;
                }

                if (isVowel(c)) {
                    vowels++;
                }
            }
        }

        return new TextStats(vowels, letters, uppercase, words);
    }

    private boolean isVowel(char c) {
        String normalized = Normalizer.normalize(
                String.valueOf(c),
                Normalizer.Form.NFD
        );

        char base = Character.toLowerCase(normalized.charAt(0));

        return base == 'a'
            || base == 'e'
            || base == 'i'
            || base == 'o'
            || base == 'u';
    }

    private int countWords(String text) {
        boolean inWord = false;
        int count = 0;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            boolean isWordChar = Character.isLetterOrDigit(c);

            if (isWordChar && !inWord) {
                count++;
                inWord = true;
            } else if (!isWordChar) {
                inWord = false;
            }
        }

        return count;
    }
}
