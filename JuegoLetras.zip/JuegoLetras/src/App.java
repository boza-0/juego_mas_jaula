import javax.swing.SwingUtilities;
/* 
 * Autores: 
 * Juan Calixto García del Hoyo
 * Ricardo Boza Villar
 */
public final class App {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TextStatsView view = new TextStatsView();
                TextStatsCalculator calculator = new TextStatsCalculator();
                TextStatsController controller =
                        new TextStatsController(view, calculator);

                controller.init();
                view.setVisible(true);
            }
        });
    }
}
