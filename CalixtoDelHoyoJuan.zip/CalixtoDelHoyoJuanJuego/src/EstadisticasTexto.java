/**
 * @author Juan Calixto del Hoyo
 * @author Ricardo Boza Villar
 */
public final class EstadisticasTexto {

    private final int vocales;
    private final int letras;
    private final int mayusculas;
    private final int palabras;

    public EstadisticasTexto(int vocales, int letras, int mayusculas, int palabras) {
        this.vocales = vocales;
        this.letras = letras;
        this.mayusculas = mayusculas;
        this.palabras = palabras;
    }

    public static EstadisticasTexto vacio() {
        return new EstadisticasTexto(0, 0, 0, 0);
    }

    public int getVocales() {
        return vocales;
    }

    public int getLetras() {
        return letras;
    }

    public int getMayusculas() {
        return mayusculas;
    }

    public int getPalabras() {
        return palabras;
    }
}
