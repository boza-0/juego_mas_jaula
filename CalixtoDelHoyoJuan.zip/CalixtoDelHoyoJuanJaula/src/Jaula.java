import java.util.concurrent.Semaphore;
/**
 * @author Juan Calixto del Hoyo
 * @author Ricardo Boza Villar
 */
public class Jaula {

    public static void main(String[] args) {

        Semaphore plato = new Semaphore(3);
        Semaphore columpio = new Semaphore(1);

        for (int i = 1; i <= 10; i++) {
            Canario canario = new Canario(i, plato, columpio);
            canario.start();
        }
    }
}
