import java.util.concurrent.Semaphore;
/**
 * @author Juan Calixto del Hoyo
 * @author Ricardo Boza Villar
 */
public class Canario extends Thread {

    private int identificador;
    private Semaphore plato;
    private Semaphore columpio;

    public Canario(int identificador, Semaphore plato, Semaphore columpio) {
        this.identificador = identificador;
        this.plato = plato;
        this.columpio = columpio;
    }

    @Override
    public void run() {
        try {
            while (true) {
                comer();
                columpiarse();
            }
        } catch (InterruptedException e) {
            System.out.println("Canario " + identificador + " interrumpido.");
        }
    }

    private void comer() throws InterruptedException {
        plato.acquire();
        System.out.println("Canario " + identificador + " empieza a comer.");
        Thread.sleep(1000);
        System.out.println("Canario " + identificador + " termina de comer.");
        plato.release();
    }

    private void columpiarse() throws InterruptedException {
        columpio.acquire();
        System.out.println("Canario " + identificador + " empieza a columpiarse.");
        Thread.sleep(500);
        System.out.println("Canario " + identificador + " termina de columpiarse.");
        columpio.release();
    }
}
