import java.text.Normalizer;
/**
 * @author Juan Calixto del Hoyo
 * @author Ricardo Boza Villar
 */
public final class CalculadoraEstadisticasTexto {

    public EstadisticasTexto calcular(String texto) {
        if (texto == null || texto.isEmpty()) {
            return EstadisticasTexto.vacio();
        }

        int vocales = 0;
        int letras = 0;
        int mayusculas = 0;
        int palabras = contarPalabras(texto);

        for (int i = 0; i < texto.length(); i++) {
            char caracter = texto.charAt(i);

            if (Character.isLetter(caracter)) {
                letras++;

                if (Character.isUpperCase(caracter)) {
                    mayusculas++;
                }

                if (esVocal(caracter)) {
                    vocales++;
                }
            }
        }

        return new EstadisticasTexto(vocales, letras, mayusculas, palabras);
    }

    private boolean esVocal(char caracter) {
        String normalizado = Normalizer.normalize(
                String.valueOf(caracter),
                Normalizer.Form.NFD
        );

        char base = Character.toLowerCase(normalizado.charAt(0));

        return base == 'a'
            || base == 'e'
            || base == 'i'
            || base == 'o'
            || base == 'u';
    }

    private int contarPalabras(String texto) {
        boolean dentroPalabra = false;
        int contador = 0;

        for (int i = 0; i < texto.length(); i++) {
            char caracter = texto.charAt(i);
            boolean esCaracterPalabra = Character.isLetterOrDigit(caracter);

            if (esCaracterPalabra && !dentroPalabra) {
                contador++;
                dentroPalabra = true;
            } else if (!esCaracterPalabra) {
                dentroPalabra = false;
            }
        }

        return contador;
    }
}
