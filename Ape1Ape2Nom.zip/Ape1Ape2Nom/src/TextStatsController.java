import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.SwingUtilities;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/* 
 * Autores: 
 * Juan Calixto García del Hoyo
 * Ricardo Boza Villar
 */
public final class TextStatsController {

    private final TextStatsView view;
    private final TextStatsCalculator calculator;
    private final ExecutorService worker;

    public TextStatsController(TextStatsView view, TextStatsCalculator calculator) {
        this.view = view;
        this.calculator = calculator;
        this.worker = Executors.newSingleThreadExecutor();
    }

    public void init() {
        view.getInputText().getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { onTextChanged(); }
            @Override public void removeUpdate(DocumentEvent e) { onTextChanged(); }
            @Override public void changedUpdate(DocumentEvent e) { onTextChanged(); }
        });
    }

    private void onTextChanged() {
        final String text = view.getInputText().getText();

        worker.submit(new Runnable() {
            @Override
            public void run() {
                final TextStats stats = calculator.calculate(text);

                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        view.renderStats(stats);
                    }
                });
            }
        });
    }

    public void shutdown() {
        worker.shutdownNow();
    }
}
